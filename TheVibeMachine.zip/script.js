
const coinButton = document.getElementById("coin-button");
const output = document.getElementById("output");

const vibes = [
  "You’re not lost — just temporarily unmapped.\nSerial #882E-DC97",
  "They forgot your name. That’s your freedom.\nCard ID: LUX-0133",
  "You’re the glitch in someone else’s simulation.",
  "Be still. The answer’s stuck in traffic.\nTimestamp: 03:14:11 AM"
];

const refunds = [
  "The Machine rejects you gently. Funds returned.",
  "Come back when the air shifts.",
  "Coin refunded. You hesitated.",
  "Refund complete. No questions.",
  "The Machine made a sound, but nothing happened."
];

coinButton.addEventListener("click", () => {
  output.classList.remove("hidden");
  const roll = Math.random();

  if (roll < 0.6) {
    const vibe = vibes[Math.floor(Math.random() * vibes.length)];
    output.textContent = vibe;
  } else if (roll < 0.9) {
    const refund = refunds[Math.floor(Math.random() * refunds.length)];
    output.textContent = refund;
  } else {
    output.textContent = "";
    output.classList.add("hidden");
  }
});
